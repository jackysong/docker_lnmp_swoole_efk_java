<?php
define("TCP_SERVER_HOST", "127.0.0.1");
define("TCP_SERVER_PORT", 9001);

define("TCP_SERVER_HOST1", "127.0.0.1");
define("TCP_SERVER_PORT1", 9011);

define("TCP_SERVER_HOST2", "127.0.0.1");
define("TCP_SERVER_PORT2", 9021);

define("HTTP_SERVER_HOST", "127.0.0.1");
define("HTTP_SERVER_PORT", 9002);
define("WEBSOCKET_SERVER_HOST", "127.0.0.1");
define("WEBSOCKET_SERVER_PORT", 9003);

define("UNIXSOCK_SERVER_PATH", __DIR__ . "/unix-sock-test.sock");

define("UDP_SERVER_HOST", "127.0.0.1");
define("UDP_SERVER_PORT", "9003");

define("REDIS_SERVER_PATH", "");
define("REDIS_SERVER_HOST", "127.0.0.1");
define("REDIS_SERVER_PORT", 6379);

define("REDIS_SERVER_PATH1", "");
define("REDIS_SERVER_HOST1", "127.0.0.1");
define("REDIS_SERVER_PORT1", 6379);

define("REDIS_SERVER_PATH2", "");
define("REDIS_SERVER_HOST2", "127.0.0.1");
define("REDIS_SERVER_PORT2", 6379);

define("REDIS_SERVER_PATH3", "");
define("REDIS_SERVER_HOST3", "127.0.0.1");
define("REDIS_SERVER_PORT3", 6379);

define("MYSQL_SERVER_HOST", "127.0.0.1");
define("MYSQL_SERVER_PORT", 3306);
define("MYSQL_SERVER_USER", "root");
define("MYSQL_SERVER_PWD", "root");
define("MYSQL_SERVER_DB", "test");

define("MYSQL_SERVER_HOST1", "127.0.0.1");
define("MYSQL_SERVER_PORT1", 3306);
define("MYSQL_SERVER_USER1", "root");
define("MYSQL_SERVER_PWD1", "");
define("MYSQL_SERVER_DB1", "test");

define("MYSQL_SERVER_HOST2", "127.0.0.1");
define("MYSQL_SERVER_PORT2", 3306);
define("MYSQL_SERVER_USER2", "root");
define("MYSQL_SERVER_PWD2", "");
define("MYSQL_SERVER_DB2", "test");

define("MYSQL_SERVER_HOST3", "127.0.0.1");
define("MYSQL_SERVER_PORT3", 3306);
define("MYSQL_SERVER_USER3", "root");
define("MYSQL_SERVER_PWD3", "");
define("MYSQL_SERVER_DB3", "test");

define("TEST_IMAGE", __DIR__ . "/../../examples/test.jpg");

define("IP_BAIDU", "180.97.33.107");

define('HTTP_PROXY_HOST', '127.0.0.1');
define('HTTP_PROXY_PORT', 8888);